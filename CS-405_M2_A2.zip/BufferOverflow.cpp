// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
#include <limits> // For std::numeric_limits

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    // The account_number must remain untouched and located just before the input buffer
    const std::string account_number = "CharlieBrown42";

    char user_input[20]; // Input buffer remains unchanged in size or location

    std::cout << "Enter a value: ";

    // Read input safely using std::cin.get to prevent overflow
    std::cin.get(user_input, sizeof(user_input));

    // Check if input failed due to too many characters or no input provided
    if (user_input[0] == '\0') {
        std::cout << "Warning: No input was provided.\n";
    }
    else if (std::cin.peek() != '\n') {
        std::cout << "Warning: You entered too much data. Input has been truncated to 19 characters.\n";
    }
    else {
        // Clean up any remaining characters to avoid affecting next input
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }

    std::cout << "You entered: " << user_input << std::endl;
    std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
