// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>  // For standard exceptions
#include <exception>  // For std::exception base class
#include <string>

// Custom exception class derived from std::exception
class CustomException : public std::exception {
public:
    CustomException(const std::string& message) : msg(message) {}
    const char* what() const noexcept override {
        // Return custom error message
        return msg.c_str();
    }
private:
    std::string msg;    // Holds exception message
};

bool do_even_more_custom_application_logic()
{
  std::cout << "Running Even More Custom Application Logic." << std::endl;

  // Throwing a standard C++ runtime_error
  throw std::runtime_error("Standard exception thrown from even more custom logic.");

  return true;
}
void do_custom_application_logic()
{
  std::cout << "Running Custom Application Logic." << std::endl;

  try {
      // Wrap call with std::exception handler
      if (do_even_more_custom_application_logic())
      {
          std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
      }
  }
  catch (const std::exception& ex) {
      // Catch and report standard exception
      std::cerr << "Caught std::exception: " << ex.what() << std::endl;
  }

  // Throw custom exception to be caught in main
  throw CustomException("Custom exception thrown from do_custom_application_logic().");

  std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
  if (den == 0.0f) {
      // Throwing standard logic_error for divide-by-zero
      throw std::logic_error("Division by zero is not allowed.");
  }
  return (num / den);
}

void do_division() noexcept
{
  float numerator = 10.0f;
  float denominator = 0;

  try {
      // Attempt division that may throw logic_error
      auto result = divide(numerator, denominator);
      std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
  }
  catch (const std::logic_error& ex) {
      // Catch and report divide-by-zero error
      std::cerr << "Caught logic_error in do_division: " << ex.what() << std::endl;
  }
}

int main()
{
  std::cout << "Exceptions Tests!" << std::endl;

  try {
      // Execute division and custom logic with exception handling
      do_division();
      do_custom_application_logic();
  }
  catch (const CustomException& customEx) {
      // Catch and display custom exception from do_custom_application_logic
      std::cerr << "Caught CustomException in main: " << customEx.what() << std::endl;
  }
  catch (const std::exception& stdEx) {
      // Catch any other std exceptions not handled earlier
      std::cerr << "Caught std::exception in main: " << stdEx.what() << std::endl;
  }
  catch (...) {
      // Catch-all for any unknown exceptions to prevent crashes
      std::cerr << "Caught an unknown exception in main." << std::endl;
  }

  return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
